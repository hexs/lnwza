import os
import sys
from . import pipp


# import install


def pipp():
    print(sys.argv)
    if sys.argv[1] == 'install' and len(sys.argv) >= 3:
        package_name_list = sys.argv[2:]

        dir_ = os.path.dirname(__file__)
        while True:
            if 'Scripts' in os.listdir(dir_):
                break
            else:
                dir_ = os.path.split(dir_)[0]
        pipp.install_package(dir_, package_name_list)


    else:
        comm = sys.argv[1:]
        dir_ = os.path.dirname(__file__)
        while True:
            if 'Scripts' in os.listdir(dir_):
                break
            else:
                dir_ = os.path.split(dir_)[0]
        pipp.other(dir_, comm)

# pipp()
