import os
import subprocess


def create_install_bat(venv_path, package_name_list, proxy_http=None):
    package_name = ' '.join(package_name_list)
    activate_bat_file = os.path.join(venv_path, r'Scripts\activate.bat')
    txt = f'@echo off\n'
    txt += f'call "{activate_bat_file}"\n'
    if proxy_http:
        txt += f'pip install --proxy {proxy_http} {package_name}\n'
    else:
        txt += f'pip install {package_name}\n'
    with open('run.bat', 'w') as f:
        f.write(txt)


def create_uninstall_bat(venv_path, package_name_list):
    package_name = ' '.join(package_name_list)
    activate_bat_file = os.path.join(venv_path, r'Scripts\activate.bat')
    txt = f'@echo off\n'
    txt += f'call "{activate_bat_file}"\n'
    txt += f'pip uninstall {package_name}\n'
    txt += f'y'
    with open('run.bat', 'w') as f:
        f.write(txt)


def delete_file(file_path):
    if os.path.isfile(file_path):
        os.remove(file_path)
    else:
        print(f"error delete file {file_path}")


def install_package(venv_path, package_name_list):
    res = subprocess.run("git config --global https.proxy", capture_output=True)
    proxy_http = res.stdout.decode().strip()

    create_install_bat(venv_path, package_name_list, proxy_http)

    subprocess.run("run.bat", shell=True)

    delete_file('run.bat')


def uninstall_package(venv_path, package_name_list):
    create_uninstall_bat(venv_path, package_name_list)

    subprocess.run("run.bat", shell=True)

    delete_file('run.bat')


if __name__ == "__main__":
    install_package('numpy')
