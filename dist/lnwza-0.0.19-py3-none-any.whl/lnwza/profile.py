# profile.py

def hello():
    print('hi!')
