def sprint(*args, sep=' ', end='\n', file=None):
    print(*args, sep=sep, end=end, file=file)
